/* generated configuration header file - do not edit */
#ifndef BOARD_CFG_H_
#define BOARD_CFG_H_
void bsp_init(void *p_args);
#endif /* BOARD_CFG_H_ */
