#include <Init_Thread.h>
#include "g_hardware.h"

extern uint8_t print_data[4];

/** Task Handler**/
TaskHandle_t Handle_FND;

/** Main Thread : Create Tasks **/
void Init_Thread_entry(void *pvParameters)
{
    FSP_PARAMETER_NOT_USED (pvParameters);
    /* Initial HW Setting */

    FND_Setting();

    /* TODO: add your own code here */
    while (1)
    {
        xTaskCreate(Task_FND, "FND", 0x100, NULL, 1, &Handle_FND);
        vTaskDelete(NULL);
    }
}


/** For handling FND **/
void Task_FND(void *pvParameters)
{
    FSP_PARAMETER_NOT_USED (pvParameters);

    /* TODO: add your own code here */
    for(;;)
    {
        R_FND_Print_Data(print_data);
    }
}





