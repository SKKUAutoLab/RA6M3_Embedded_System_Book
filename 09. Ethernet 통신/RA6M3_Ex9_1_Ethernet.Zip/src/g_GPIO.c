/*
 * g_GPIO.c
 *
 *  Created on: 2023. 11. 28.
 *      Author: Embedded System Lab
 */

#include <g_GPIO.h>

uint8_t number[11] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xD8, 0x80, 0x90, 0xFF};

void R_FND_Initial_Setting()
{
    /* 7-Segment LED Pin Output Setting */
    R_PORT3->PCNTR1_b.PDR |= (uint32_t)0x01E0;
    R_PORT6->PCNTR1_b.PDR |= (uint32_t)0x78F0;

    R_FND_Reset();
}
void R_FND_Reset()
{
    /* 7-Segment LED Pin State Initialization */
    R_PORT3->PCNTR1_b.PODR &= ~PODR_DIGIT_MASK & 0xFFFF;
    R_PORT6->PCNTR1_b.PODR |= PODR_PIN_MASK;
}
void R_FND_Print_Data(uint8_t *string)
{
    uint8_t idx = 0;

    if (sizeof(string) != DIGIT_INDEX)
        return;

    for (idx = 0; idx < DIGIT_INDEX; idx++)
        R_FND_Display_Data(idx, number[string[idx]]);
}
void R_FND_Display_Data(uint8_t digit, uint8_t data)
{
    uint16_t high_nibble = (uint16_t)((data << PODR_INDEX_HIGH) & PODR_HIGH_MASK);
    uint16_t low_nibble = (uint16_t)((data << PODR_INDEX_LOW) & PODR_LOW_MASK);

    R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MICROSECONDS);
    R_FND_Reset();

    /* 7-Segment Digit Selection */
    R_PORT3->PCNTR1_b.PODR = (uint16_t)((0x0010 << (1 + digit)) & PODR_DIGIT_MASK);

    /* 7-Segment LED Pin State Setting */
    R_PORT6->PCNTR1_b.PODR = high_nibble | low_nibble;
}
