/*
 * g_ethernet_lib.h
 *
 *  Created on: 2023. 3. 7.
 *      Author: Embedded System Lab
 */

#include <hal_data.h>

#ifndef G_ETHERNET_LIB_H_
#define G_ETHERNET_LIB_H_

//////////////////////// USER DEFINITION AREA (Ethernet Parameters) ////////////////////////

#define ETH_VLAN_MODE                   false


#define VLAN_PRI                        0b001                   // [15:13] VLAN Priority Code Point (3-bit)
#define VLAN_DEI                        0b1                     // [12:12] VLAN Drop Eligible Indicator (1-bit)
#define VLAN_ID                         0b000000110000          // [11: 0] VLAN Identifier (12-bit)

////////////////////////////////////////////////////////////////////////////////////////////

#define ETH_MTU_SIZE                    1500                    // Ethernet II Frame Maximum Transmission Unit Size

#define STRUCT_SHIFT_SIZE               8
#define FULL_MASK_8BIT                  0xFF
#define FULL_MASK_16BIT                 0xFFFF
#define FULL_MASK_32BIT                 0xFFFFFFFF

#define ETH_MAC_ADDR_SIZE               6                       // Ethernet II Frame MAC Address Size
#define ETH_VLAN_TAG_SIZE               2                       // Ethernet VLAN Tag Size
#define ETH_TYPE_SIZE                   2                       // Ethernet II Frame Type Size

#define ETH_MAC_HEAD_SIZE               (ETH_MAC_ADDR_SIZE * 2 + ETH_TYPE_SIZE * 3)
#define ETH_FRAME_SIZE                  (ETH_MAC_HEAD_SIZE + ETH_MTU_SIZE)

#define ETH_VLAN_TYPE                   0x8100
#define ETH_NORMAL_TYPE                 0xE901

typedef struct _ethFrameStr             ethFrameStr;

void R_Eth_Initial_Setting();
void setLayer2(uint8_t *dMAC, uint8_t *sMAC, const char *msg);
void setEthFrame(uint8_t *dMAC, uint8_t *sMAC, const char *msg);
int checkingMsg(const char *cmsgA, const char *cmsgB);

typedef struct _ethFrameStr{
    ///////////////////////////////////////////////////////////////////
    /// Support Data-link Layer (OSI-2nd-Layer) (Ethernet II Frame) ///
    ///////////////////////////////////////////////////////////////////

    uint8_t                 dstMAC[ETH_MAC_ADDR_SIZE];  // Destination MAC Address (6bytes)
    uint8_t                 srcMAC[ETH_MAC_ADDR_SIZE];  // Source MAC Address (6bytes)

#if ETH_VLAN_MODE
    uint8_t                 VLANType[ETH_TYPE_SIZE];    // VLAN Type: 0x8100 (2bytes)

    uint8_t                 IDH : 4;                    // VLAN Tag ID High
    uint8_t                 DEI : 1;                    // VLAN Tag DEI
    uint8_t                 PRI : 3;                    // VLAN Tag Priority
    uint8_t                 IDL : 8;                    // VLAN Tag ID Low
#endif

    uint8_t                 ethType[ETH_TYPE_SIZE];     // EtherType (2bytes)

    ////////////////////////////////////////////////////////////////////
    ///                     Support Payload Area                     ///
    ////////////////////////////////////////////////////////////////////

    uint8_t                 payload[ETH_MTU_SIZE];

} ethFrameStr;


#endif /* G_ETHERNET_LIB_H_ */
