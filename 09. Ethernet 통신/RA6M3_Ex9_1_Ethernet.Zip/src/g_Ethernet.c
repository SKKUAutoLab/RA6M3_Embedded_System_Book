/*
 * g_ethernet_lib.c
 *
 *  Created on: 2023. 3. 7.
 *      Author: Embedded System Lab
 */

#include <g_Ethernet.h>
#include <g_DeviceDriver.h>

extern ethFrameStr          TxFrameBuffer;
extern ethFrameStr          RxFrameBuffer;

uint16_t                    TxFrameSize = 0;               // Length(Size) of Transmitted Ethernet Message

void R_Eth_Initial_Setting()
{
    fsp_err_t err = FSP_SUCCESS;

    R_ETHER_Open(&g_ether0_ctrl, &g_ether0_cfg);

    do {
        err = R_ETHER_LinkProcess(&g_ether0_ctrl);
    } while (FSP_SUCCESS != err);

    R_ETHERC_EDMAC->EESIPR_b.TCIP = 0U; // Disable Transmit Interrupt Setting

    memset(&RxFrameBuffer, 0, sizeof(ethFrameStr));
    R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_10_PIN_08, BSP_IO_LEVEL_LOW);
}

void setLayer2(uint8_t *dMAC, uint8_t *sMAC, const char *msg)
{
    // Ethernet Frame Destination & Source MAC Address Setting //
    memcpy(&TxFrameBuffer.dstMAC[0], dMAC, ETH_MAC_ADDR_SIZE);
    memcpy(&TxFrameBuffer.srcMAC[0], sMAC, ETH_MAC_ADDR_SIZE);

#if ETH_VLAN_MODE
    // Ethernet Frame VLAN Type Setting: 0x8100 //
    TxFrameBuffer.VLANType[0] = (uint8_t)(ETH_VLAN_TYPE >> STRUCT_SHIFT_SIZE);
    TxFrameBuffer.VLANType[1] = (uint8_t)(ETH_VLAN_TYPE & FULL_MASK_8BIT);

    // Ethernet Frame VLAN Security Setting //
    TxFrameBuffer.PRI = VLAN_PRI;
    TxFrameBuffer.DEI = VLAN_DEI;
    TxFrameBuffer.IDH = VLAN_ID >> STRUCT_SHIFT_SIZE;
    TxFrameBuffer.IDL = VLAN_ID & 0xFF;
#endif

    // Ethernet Frame Type Setting: Exercise Type [0xE901] //
    TxFrameBuffer.ethType[0] = (uint8_t)(ETH_NORMAL_TYPE >> STRUCT_SHIFT_SIZE);
    TxFrameBuffer.ethType[1] = (uint8_t)(ETH_NORMAL_TYPE & FULL_MASK_8BIT);

    // Ethernet Frame Length Setting //
    uint16_t payloadLen = (uint16_t)strlen(msg);
    TxFrameBuffer.payload[0] = (uint8_t)(payloadLen >> STRUCT_SHIFT_SIZE);
    TxFrameBuffer.payload[1] = (uint8_t)(payloadLen & FULL_MASK_8BIT);

    // Ethernet Frame Payload Setting //
    memcpy(&TxFrameBuffer.payload[2], msg, strlen(msg));
}

void setEthFrame(uint8_t *dMAC, uint8_t *sMAC, const char *msg)
{
    memset(&TxFrameBuffer, 0, sizeof(ethFrameStr));
    setLayer2(dMAC, sMAC, msg);

#if ETH_VLAN_MODE
    TxFrameSize = (uint16_t)(ETH_MAC_ADDR_SIZE * 2 + ETH_TYPE_SIZE + ETH_TYPE_SIZE + strlen(msg) + 2);
#else
    TxFrameSize = (uint16_t)(ETH_MAC_ADDR_SIZE * 2 + ETH_TYPE_SIZE + strlen(msg) + 2);
#endif
}
int checkingMsg(const char *cmsgA, const char *cmsgB)
{
    int checkValH = false, checkValL = false;

    checkValH = strncmp(cmsgA, (const char *)&RxFrameBuffer.payload[2], 29);
    checkValL = strncmp(cmsgB, (const char *)&RxFrameBuffer.payload[32], 19);

    return checkValH + checkValL;
}
